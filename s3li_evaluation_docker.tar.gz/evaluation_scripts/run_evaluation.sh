#!/bin/bash
# run_evaluation.sh - Run SLAM evaluations on S3LI dataset

set -e

source /opt/ros/noetic/setup.bash
source /workspace/catkin_ws/devel/setup.bash 2>/dev/null || true

DATASET_DIR="/workspace/dataset"
RESULTS_DIR="/workspace/results"
SCRIPTS_DIR="/workspace/scripts"

echo "=========================================="
echo "S3LI Dataset SLAM Evaluation"
echo "=========================================="

# Check if dataset exists
if [ ! -d "$DATASET_DIR" ] || [ -z "$(ls -A $DATASET_DIR)" ]; then
    echo "Error: Dataset not found in $DATASET_DIR"
    echo "Please run: bash /workspace/scripts/download_dataset.sh"
    exit 1
fi

# List available sequences
echo "Available sequences:"
SEQUENCES=($(ls -d $DATASET_DIR/s3li_* 2>/dev/null | xargs -n 1 basename || echo ""))

if [ ${#SEQUENCES[@]} -eq 0 ]; then
    echo "No sequences found!"
    exit 1
fi

for i in "${!SEQUENCES[@]}"; do
    echo "  $((i+1)). ${SEQUENCES[$i]}"
done
echo "  $((${#SEQUENCES[@]}+1)). Run all sequences"
echo "  $((${#SEQUENCES[@]}+2)). Run Table III comparison"
echo ""

# SLAM systems to evaluate
SLAM_SYSTEMS=(
    "ORB_SLAM3_Stereo"
    "ORB_SLAM3_Stereo_Inertial"
    "VINS_Fusion_Stereo"
    "VINS_Fusion_Stereo_Inertial"
    "OPEN_VINS"
    "BASALT"
)

echo "SLAM systems to evaluate:"
for sys in "${SLAM_SYSTEMS[@]}"; do
    echo "  - $sys"
done
echo ""

# Function to run ORB-SLAM3
run_orbslam3() {
    local sequence=$1
    local mode=$2  # "stereo" or "stereo-inertial"
    
    echo "Running ORB-SLAM3 ($mode) on $sequence..."
    
    local vocab_file="/workspace/ORB_SLAM3/Vocabulary/ORBvoc.txt"
    local settings_file="/workspace/configs/orbslam3_${sequence}.yaml"
    local result_dir="$RESULTS_DIR/orbslam3_${mode}/$sequence"
    
    mkdir -p $result_dir
    
    cd /workspace/ORB_SLAM3
    
    if [ "$mode" == "stereo" ]; then
        ./Examples/Stereo/stereo_euroc \
            $vocab_file \
            $settings_file \
            $DATASET_DIR/$sequence \
            $result_dir/timestamps.txt \
            > $result_dir/output.log 2>&1 || true
    else
        ./Examples/Stereo-Inertial/stereo_inertial_euroc \
            $vocab_file \
            $settings_file \
            $DATASET_DIR/$sequence \
            $result_dir/timestamps.txt \
            > $result_dir/output.log 2>&1 || true
    fi
    
    echo "✓ ORB-SLAM3 ($mode) completed for $sequence"
}

# Function to run VINS-Fusion
run_vins_fusion() {
    local sequence=$1
    local mode=$2
    
    echo "Running VINS-Fusion ($mode) on $sequence..."
    
    local result_dir="$RESULTS_DIR/vins_fusion_${mode}/$sequence"
    mkdir -p $result_dir
    
    cd /workspace/catkin_ws
    source devel/setup.bash
    
    # Launch VINS-Fusion with appropriate config
    roslaunch vins vins_rviz.launch &
    VINS_PID=$!
    sleep 5
    
    # Play dataset
    python3 $SCRIPTS_DIR/dataset_player.py \
        --sequence $DATASET_DIR/$sequence \
        --output $result_dir \
        --mode $mode \
        > $result_dir/output.log 2>&1 || true
    
    kill $VINS_PID || true
    
    echo "✓ VINS-Fusion ($mode) completed for $sequence"
}

# Function to run OpenVINS
run_openvins() {
    local sequence=$1
    
    echo "Running OpenVINS on $sequence..."
    
    local result_dir="$RESULTS_DIR/openvins/$sequence"
    mkdir -p $result_dir
    
    cd /workspace/catkin_ws
    source devel/setup.bash
    
    roslaunch ov_msckf pgeneva_ros_eth.launch &
    OPENVINS_PID=$!
    sleep 5
    
    python3 $SCRIPTS_DIR/dataset_player.py \
        --sequence $DATASET_DIR/$sequence \
        --output $result_dir \
        --mode stereo_imu \
        > $result_dir/output.log 2>&1 || true
    
    kill $OPENVINS_PID || true
    
    echo "✓ OpenVINS completed for $sequence"
}

# Function to run BASALT
run_basalt() {
    local sequence=$1
    
    echo "Running BASALT on $sequence..."
    
    local result_dir="$RESULTS_DIR/basalt/$sequence"
    mkdir -p $result_dir
    
    cd /workspace/basalt/build
    
    ./basalt_vio \
        --dataset-path $DATASET_DIR/$sequence \
        --config-path /workspace/configs/basalt_config.json \
        --result-path $result_dir \
        --save-trajectory \
        > $result_dir/output.log 2>&1 || true
    
    echo "✓ BASALT completed for $sequence"
}

# Function to evaluate results
evaluate_results() {
    local sequence=$1
    
    echo "Evaluating results for $sequence..."
    
    python3 $SCRIPTS_DIR/evaluate_trajectory.py \
        --sequence $sequence \
        --results_dir $RESULTS_DIR \
        --groundtruth $DATASET_DIR/$sequence/groundtruth.txt \
        --output $RESULTS_DIR/evaluation_${sequence}.csv
}

# Main execution
read -p "Enter your choice: " choice

if [ "$choice" -le "${#SEQUENCES[@]}" ]; then
    # Run single sequence
    SEQ="${SEQUENCES[$((choice-1))]}"
    echo "Running evaluation on $SEQ"
    
    # Run each SLAM system
    run_orbslam3 "$SEQ" "stereo"
    run_orbslam3 "$SEQ" "stereo-inertial"
    run_vins_fusion "$SEQ" "stereo"
    run_vins_fusion "$SEQ" "stereo-inertial"
    run_openvins "$SEQ"
    run_basalt "$SEQ"
    
    # Evaluate
    evaluate_results "$SEQ"
    
elif [ "$choice" -eq "$((${#SEQUENCES[@]}+1))" ]; then
    # Run all sequences
    for SEQ in "${SEQUENCES[@]}"; do
        echo "Processing $SEQ..."
        run_orbslam3 "$SEQ" "stereo"
        run_orbslam3 "$SEQ" "stereo-inertial"
        run_vins_fusion "$SEQ" "stereo"
        run_vins_fusion "$SEQ" "stereo-inertial"
        run_openvins "$SEQ"
        run_basalt "$SEQ"
        evaluate_results "$SEQ"
    done
    
    # Generate summary table
    python3 $SCRIPTS_DIR/generate_table.py \
        --results_dir $RESULTS_DIR \
        --output $RESULTS_DIR/table_iii_comparison.csv
    
elif [ "$choice" -eq "$((${#SEQUENCES[@]}+2))" ]; then
    # Generate Table III comparison from existing results
    python3 $SCRIPTS_DIR/generate_table.py \
        --results_dir $RESULTS_DIR \
        --output $RESULTS_DIR/table_iii_comparison.csv
fi

echo ""
echo "=========================================="
echo "Evaluation complete!"
echo "=========================================="
echo "Results saved to: $RESULTS_DIR"
echo ""
