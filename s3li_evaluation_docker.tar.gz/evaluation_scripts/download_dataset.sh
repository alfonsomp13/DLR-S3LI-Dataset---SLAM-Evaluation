#!/bin/bash
# download_dataset.sh - Download S3LI dataset from DLR

set -e

DATASET_URL="https://datasets.arches-projekt.de/s3li_dataset"
DATASET_DIR="/workspace/dataset"

echo "=========================================="
echo "Downloading DLR S3LI Dataset"
echo "=========================================="

cd $DATASET_DIR

# List of sequences from the paper
SEQUENCES=(
    "s3li_traverse_1"
    "s3li_traverse_2"
    "s3li_crater"
    "s3li_loops"
    "s3li_crater_inout"
    "s3li_mapping"
    "s3li_landmarks"
)

echo "Available sequences:"
for i in "${!SEQUENCES[@]}"; do
    echo "  $((i+1)). ${SEQUENCES[$i]}"
done
echo "  8. Download all"
echo ""

# Download function
download_sequence() {
    local seq=$1
    echo "Downloading $seq..."
    
    # Create sequence directory
    mkdir -p $seq
    cd $seq
    
    # Download main data files
    # Note: Adjust URLs based on actual dataset structure
    wget -nc -r -np -nH --cut-dirs=2 \
        -A "*.bag,*.tar.gz,*.zip,*.yaml,*.txt" \
        "${DATASET_URL}/${seq}/" || true
    
    # Extract if compressed
    if ls *.tar.gz 1> /dev/null 2>&1; then
        echo "Extracting compressed files..."
        for f in *.tar.gz; do
            tar -xzf "$f"
        done
    fi
    
    if ls *.zip 1> /dev/null 2>&1; then
        echo "Extracting zip files..."
        for f in *.zip; do
            unzip -o "$f"
        done
    fi
    
    cd ..
    echo "✓ $seq downloaded"
}

# Interactive mode if run directly
if [ -t 0 ]; then
    read -p "Enter sequence number (1-8): " choice
    
    if [ "$choice" -eq 8 ]; then
        for seq in "${SEQUENCES[@]}"; do
            download_sequence "$seq"
        done
    elif [ "$choice" -ge 1 ] && [ "$choice" -le 7 ]; then
        download_sequence "${SEQUENCES[$((choice-1))]}"
    else
        echo "Invalid choice"
        exit 1
    fi
else
    # Non-interactive mode - download all
    for seq in "${SEQUENCES[@]}"; do
        download_sequence "$seq"
    done
fi

echo ""
echo "=========================================="
echo "Dataset download complete!"
echo "=========================================="
echo "Dataset location: $DATASET_DIR"
echo ""
echo "Calibration files are in: $DATASET_DIR/<sequence>/calib/"
echo "Stereo images: $DATASET_DIR/<sequence>/cam0/ and cam1/"
echo "LiDAR scans: $DATASET_DIR/<sequence>/lidar/"
echo "IMU data: $DATASET_DIR/<sequence>/imu/"
echo "Ground truth: $DATASET_DIR/<sequence>/groundtruth.txt"
echo ""
