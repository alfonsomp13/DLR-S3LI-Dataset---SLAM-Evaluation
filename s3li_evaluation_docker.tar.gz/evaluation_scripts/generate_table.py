#!/usr/bin/env python3
"""
generate_table.py - Generate Table III comparison from evaluation results
Reproduces the table from the paper comparing SLAM algorithms
"""

import numpy as np
import pandas as pd
import argparse
import os
import glob
import csv

def format_result(rmse_norm, completion):
    """Format result as in Table III: 'rmse (completion%)'"""
    if rmse_norm is None or completion == 0:
        return '-'
    return f"{rmse_norm:.2f} ({int(completion*100)})"

def main():
    parser = argparse.ArgumentParser(description='Generate Table III comparison')
    parser.add_argument('--results_dir', required=True, help='Results directory')
    parser.add_argument('--output', required=True, help='Output CSV file')
    
    args = parser.parse_args()
    
    # Find all evaluation CSV files
    eval_files = glob.glob(os.path.join(args.results_dir, 'evaluation_*.csv'))
    
    if not eval_files:
        print("Error: No evaluation results found!")
        return
    
    # Load all results
    all_results = []
    for f in eval_files:
        df = pd.read_csv(f)
        all_results.append(df)
    
    combined = pd.concat(all_results, ignore_index=True)
    
    # Sequences from the paper
    sequences = [
        's3li_traverse_1',
        's3li_loops',
        's3li_crater',
        's3li_crater_inout',
        's3li_landmarks',
        's3li_mapping',
        's3li_traverse_2'
    ]
    
    # Algorithm mapping
    algo_map = {
        'orbslam3_stereo': 'ORB-SLAM3 (S)',
        'orbslam3_stereo-inertial': 'ORB-SLAM3 (SI)',
        'vins_fusion_stereo': 'VINS_Fusion (S)',
        'vins_fusion_stereo-inertial': 'VINS_Fusion (SI)',
        'openvins': 'OPEN_VINS',
        'basalt': 'BASALT (SI)'
    }
    
    # Create table
    table_data = []
    
    for algo_key, algo_name in algo_map.items():
        row = {'Algorithm': algo_name}
        
        for seq in sequences:
            # Find result for this algorithm and sequence
            result = combined[(combined['system'] == algo_key) & 
                            (combined['sequence'] == seq)]
            
            if len(result) == 0:
                row[seq] = '-'
            else:
                rmse = result['rmse_normalized'].values[0]
                completion = result['completion_ratio'].values[0]
                
                if pd.isna(rmse):
                    row[seq] = '-'
                else:
                    row[seq] = format_result(rmse, completion)
        
        table_data.append(row)
    
    # Create DataFrame
    df_table = pd.DataFrame(table_data)
    
    # Save to CSV
    df_table.to_csv(args.output, index=False)
    
    print("\n" + "="*80)
    print("Table III: SLAM Algorithm Comparison (Normalized RMSE and Completion %)")
    print("="*80)
    print(df_table.to_string(index=False))
    print("="*80)
    print(f"\nTable saved to: {args.output}")
    
    # Also create a detailed statistics file
    stats_output = args.output.replace('.csv', '_detailed.csv')
    
    # Calculate statistics
    stats = []
    for algo_key, algo_name in algo_map.items():
        algo_results = combined[combined['system'] == algo_key]
        
        valid_results = algo_results[algo_results['status'] == 'success']
        
        if len(valid_results) > 0:
            stats.append({
                'Algorithm': algo_name,
                'Sequences Completed': len(valid_results),
                'Total Sequences': len(sequences),
                'Success Rate': f"{len(valid_results)/len(sequences)*100:.1f}%",
                'Avg RMSE (normalized)': valid_results['rmse_normalized'].mean(),
                'Avg Completion': f"{valid_results['completion_ratio'].mean()*100:.1f}%",
                'Best RMSE': valid_results['rmse_normalized'].min(),
                'Worst RMSE': valid_results['rmse_normalized'].max()
            })
    
    df_stats = pd.DataFrame(stats)
    df_stats.to_csv(stats_output, index=False)
    
    print("\n" + "="*80)
    print("Detailed Statistics")
    print("="*80)
    print(df_stats.to_string(index=False))
    print("="*80)
    print(f"\nDetailed statistics saved to: {stats_output}")

if __name__ == '__main__':
    main()
