#!/usr/bin/env python3
"""
evaluate_trajectory.py - Evaluate SLAM trajectories against ground truth
Computes normalized RMSE as described in the paper
"""

import numpy as np
import argparse
import os
import sys
from scipy.spatial.transform import Rotation
import csv

def load_trajectory(filepath):
    """Load trajectory from file (timestamp, x, y, z, qx, qy, qz, qw)"""
    data = np.loadtxt(filepath)
    if data.shape[1] >= 8:
        timestamps = data[:, 0]
        positions = data[:, 1:4]
        orientations = data[:, 4:8]
        return timestamps, positions, orientations
    elif data.shape[1] >= 4:
        timestamps = data[:, 0]
        positions = data[:, 1:4]
        return timestamps, positions, None
    else:
        raise ValueError("Invalid trajectory format")

def associate_timestamps(gt_stamps, est_stamps, max_diff=0.02):
    """Associate ground truth and estimated timestamps"""
    associations = []
    for i, est_t in enumerate(est_stamps):
        diffs = np.abs(gt_stamps - est_t)
        min_idx = np.argmin(diffs)
        if diffs[min_idx] < max_diff:
            associations.append((min_idx, i))
    return associations

def align_trajectories(gt_pos, est_pos):
    """Align estimated trajectory to ground truth using Horn's method"""
    # Compute centroids
    gt_centroid = np.mean(gt_pos, axis=0)
    est_centroid = np.mean(est_pos, axis=0)
    
    # Center the point clouds
    gt_centered = gt_pos - gt_centroid
    est_centered = est_pos - est_centroid
    
    # Compute cross-covariance matrix
    H = est_centered.T @ gt_centered
    
    # SVD
    U, S, Vt = np.linalg.svd(H)
    
    # Compute rotation
    R = Vt.T @ U.T
    
    # Handle reflection case
    if np.linalg.det(R) < 0:
        Vt[-1, :] *= -1
        R = Vt.T @ U.T
    
    # Compute scale
    scale = np.sum(S) / np.sum(est_centered ** 2)
    
    # Compute translation
    t = gt_centroid - scale * R @ est_centroid
    
    # Apply transformation
    aligned = scale * (R @ est_pos.T).T + t
    
    return aligned, R, t, scale

def compute_rmse(gt_pos, est_pos):
    """Compute RMSE between trajectories"""
    errors = np.linalg.norm(gt_pos - est_pos, axis=1)
    rmse = np.sqrt(np.mean(errors ** 2))
    return rmse

def compute_trajectory_length(positions):
    """Compute total trajectory length"""
    diffs = np.diff(positions, axis=0)
    distances = np.linalg.norm(diffs, axis=1)
    return np.sum(distances)

def main():
    parser = argparse.ArgumentParser(description='Evaluate SLAM trajectory')
    parser.add_argument('--sequence', required=True, help='Sequence name')
    parser.add_argument('--results_dir', required=True, help='Results directory')
    parser.add_argument('--groundtruth', required=True, help='Ground truth file')
    parser.add_argument('--output', required=True, help='Output CSV file')
    
    args = parser.parse_args()
    
    # Load ground truth
    print(f"Loading ground truth from {args.groundtruth}")
    if not os.path.exists(args.groundtruth):
        print(f"Error: Ground truth file not found: {args.groundtruth}")
        return
    
    gt_stamps, gt_pos, gt_orient = load_trajectory(args.groundtruth)
    gt_length = compute_trajectory_length(gt_pos)
    
    print(f"Ground truth trajectory length: {gt_length:.2f} m")
    
    # SLAM systems to evaluate
    systems = [
        'orbslam3_stereo',
        'orbslam3_stereo-inertial',
        'vins_fusion_stereo',
        'vins_fusion_stereo-inertial',
        'openvins',
        'basalt'
    ]
    
    results = []
    
    for system in systems:
        traj_file = os.path.join(args.results_dir, system, args.sequence, 'trajectory.txt')
        
        if not os.path.exists(traj_file):
            print(f"Warning: Trajectory not found for {system}")
            results.append({
                'system': system,
                'sequence': args.sequence,
                'rmse': None,
                'rmse_normalized': None,
                'completion_ratio': 0.0,
                'status': 'not_found'
            })
            continue
        
        try:
            # Load estimated trajectory
            est_stamps, est_pos, est_orient = load_trajectory(traj_file)
            
            # Associate timestamps
            associations = associate_timestamps(gt_stamps, est_stamps)
            
            if len(associations) < 10:
                print(f"Warning: Too few associations for {system}")
                results.append({
                    'system': system,
                    'sequence': args.sequence,
                    'rmse': None,
                    'rmse_normalized': None,
                    'completion_ratio': 0.0,
                    'status': 'insufficient_data'
                })
                continue
            
            # Extract associated positions
            gt_indices = [a[0] for a in associations]
            est_indices = [a[1] for a in associations]
            
            gt_pos_assoc = gt_pos[gt_indices]
            est_pos_assoc = est_pos[est_indices]
            
            # Align trajectories
            aligned_pos, R, t, scale = align_trajectories(gt_pos_assoc, est_pos_assoc)
            
            # Compute RMSE
            rmse = compute_rmse(gt_pos_assoc, aligned_pos)
            
            # Compute completion ratio
            est_length = compute_trajectory_length(est_pos)
            completion_ratio = est_length / gt_length
            
            # Normalized RMSE
            rmse_normalized = rmse / gt_length
            
            print(f"{system}: RMSE = {rmse:.3f} m, Normalized RMSE = {rmse_normalized:.4f}, Completion = {completion_ratio:.2%}")
            
            results.append({
                'system': system,
                'sequence': args.sequence,
                'rmse': rmse,
                'rmse_normalized': rmse_normalized,
                'completion_ratio': completion_ratio,
                'status': 'success'
            })
            
        except Exception as e:
            print(f"Error processing {system}: {str(e)}")
            results.append({
                'system': system,
                'sequence': args.sequence,
                'rmse': None,
                'rmse_normalized': None,
                'completion_ratio': 0.0,
                'status': f'error: {str(e)}'
            })
    
    # Save results
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    with open(args.output, 'w', newline='') as f:
        fieldnames = ['system', 'sequence', 'rmse', 'rmse_normalized', 'completion_ratio', 'status']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    
    print(f"\nResults saved to {args.output}")

if __name__ == '__main__':
    main()
